function nextStep(current) {
  const totalSteps = 4;
  document.getElementById("step" + current).classList.add("hidden");
  const next = current + 1;
  if (next <= totalSteps) {
    document.getElementById("step" + next).classList.remove("hidden");
    document.getElementById("progressBar").textContent = "Step " + next + " of " + totalSteps;
  }
}
